import bcrypt from 'bcryptjs';
import { UserModel } from './models/User.js';
import { PostModel } from './models/Post.js';
import { getIsMongoConnected, readFallbackDB, writeFallbackDB } from './db.js';

// Publisher account is created from environment variables only. No credentials live in the code.
const seedEmail = process.env.PUBLISHER_EMAIL;
const seedPassword = process.env.PUBLISHER_PASSWORD;
if (process.env.PUBLISHER_PASSWORD && process.env.PUBLISHER_PASSWORD.length < 12) {
  console.warn('PUBLISHER_PASSWORD is shorter than 12 characters. No publisher account was created.');
}
const SEED_PUBLISHERS: Array<{ name: string; email: string; password: string; role: 'publisher' }> =
  seedEmail && seedPassword && seedPassword.length >= 12
    ? [{ name: process.env.PUBLISHER_NAME || 'Publisher', email: seedEmail, password: seedPassword, role: 'publisher' }]
    : [];

const INITIAL_POSTS: any[] = [];

export async function seedDatabase() {
  if (getIsMongoConnected()) {
    try {
      const User = UserModel as any;
      const Post = PostModel as any;

      // Check / Seed Publishers
      for (const pub of SEED_PUBLISHERS) {
        const existingUser = await User.findOne({ email: pub.email });
        if (!existingUser) {
          const passwordHash = await bcrypt.hash(pub.password, 12);
          await User.create({
            name: pub.name,
            email: pub.email,
            passwordHash,
            role: pub.role,
          });
          console.log(`✓ Seeded publisher user in MongoDB: ${pub.email}`);
        }
      }

      // Check / Seed Initial Posts
      const postCount = await Post.countDocuments();
      if (postCount === 0) {
        for (const post of INITIAL_POSTS) {
          await Post.create(post);
        }
        console.log(`✓ Seeded ${INITIAL_POSTS.length} initial published posts into MongoDB`);
      }
      return;
    } catch (err) {
      console.error('Mongo seed error', err);
    }
  }

  // Fallback DB Seeding
  const db = readFallbackDB();
  let modified = false;

  // Check all publishers
  for (const pub of SEED_PUBLISHERS) {
    const existingIndex = db.users.findIndex(u => u.email.toLowerCase() === pub.email.toLowerCase());
    if (existingIndex === -1) {
      const passwordHash = await bcrypt.hash(pub.password, 12);
      db.users.push({
        _id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: pub.name,
        email: pub.email,
        passwordHash,
        role: 'publisher',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      modified = true;
      console.log(`✓ Seeded publisher user in local store: ${pub.email}`);
    }
  }

  // Check posts
  if (INITIAL_POSTS.length > 0 && db.posts.length === 0) {
    db.posts = INITIAL_POSTS.map((p, idx) => ({
      _id: `post_seed_${idx + 1}`,
      ...p,
    }));
    modified = true;
    console.log(`✓ Seeded ${INITIAL_POSTS.length} initial published posts in local store`);
  }

  if (modified) {
    writeFallbackDB(db);
  }
}
