import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { UserModel } from '../models/User.js';
import { getIsMongoConnected, readFallbackDB } from '../db.js';
import { getJwtSecret, cookieOptions, JWT_ISSUER, SESSION_HOURS, requirePublisherAuth, AuthRequest } from '../middleware/auth.js';
import { validateBody, loginSchema } from '../middleware/validation.js';

const router = Router();
// Used to spend the same time on unknown emails as on wrong passwords.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);

// POST /api/auth/login
router.post('/login', validateBody(loginSchema), async (req, res: Response) => {
  const { email, password } = req.body;
  const normalizedEmail = email.toLowerCase().trim();

  let user: { id: string; name: string; email: string; passwordHash: string; role: 'publisher' } | null = null;

  if (getIsMongoConnected()) {
    try {
      const doc = await (UserModel as any).findOne({ email: normalizedEmail });
      if (doc) {
        user = {
          id: doc._id.toString(),
          name: doc.name,
          email: doc.email,
          passwordHash: doc.passwordHash,
          role: doc.role,
        };
      }
    } catch (err) {
      console.error('Mongo user query error');
    }
  }

  // Fallback to local DB if not in mongo or mongo offline
  if (!user) {
    const fallbackDB = readFallbackDB();
    const found = fallbackDB.users.find(u => u.email.toLowerCase() === normalizedEmail);
    if (found) {
      user = {
        id: found._id,
        name: found.name,
        email: found.email,
        passwordHash: found.passwordHash,
        role: found.role,
      };
    }
  }

  const isMatch = await bcrypt.compare(password, user ? user.passwordHash : DUMMY_HASH);
  if (!user || !isMatch) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const payload = { id: user.id, name: user.name, email: user.email, role: user.role };
  const token = jwt.sign(payload, getJwtSecret(), {
    algorithm: 'HS256',
    issuer: JWT_ISSUER,
    expiresIn: `${SESSION_HOURS}h`,
  });

  res.cookie('token', token, { ...cookieOptions(), maxAge: SESSION_HOURS * 60 * 60 * 1000 });

  return res.json({
    user: payload,
    message: 'Publisher authenticated successfully',
  });
});

// POST /api/auth/logout
router.post('/logout', (req, res: Response) => {
  res.clearCookie('token', cookieOptions());
  return res.json({ message: 'Logged out successfully' });
});

// GET /api/auth/me
router.get('/me', requirePublisherAuth, (req: AuthRequest, res: Response) => {
  return res.json({ user: req.user });
});

export default router;
