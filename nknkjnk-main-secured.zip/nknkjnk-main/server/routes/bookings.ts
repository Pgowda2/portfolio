import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { requirePublisherAuth } from '../middleware/auth.js';
import { validateBody, bookingSchema } from '../middleware/validation.js';

const router = Router();
const DATA_DIR = path.join(process.cwd(), 'data');
const BOOKINGS_FILE = path.join(DATA_DIR, 'bookings.json');

function getStoredBookings(): any[] {
  try {
    if (fs.existsSync(BOOKINGS_FILE)) return JSON.parse(fs.readFileSync(BOOKINGS_FILE, 'utf-8'));
  } catch {
    console.error('Error reading bookings file');
  }
  return [];
}

function saveBookings(bookings: any[]) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  const tmp = `${BOOKINGS_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(bookings, null, 2), { encoding: 'utf-8', mode: 0o600 });
  fs.renameSync(tmp, BOOKINGS_FILE);
}

// POST /api/bookings: public, validated and rate limited
router.post('/bookings', validateBody(bookingSchema), (req: Request, res: Response) => {
  try {
    const b = req.body;
    const booking = {
      id: `booking-${crypto.randomUUID()}`,
      createdAt: new Date().toISOString(),
      parentName: b.parentName,
      studentName: b.studentName,
      studentGrade: b.studentGrade || 'Grades 5-8',
      subjectInterest: b.subjectInterest || 'Python',
      email: b.email,
      phone: b.phone,
      preferredDate: b.preferredDate,
      preferredTime: b.preferredTime || '04:00 PM - 05:00 PM',
      timezone: b.timezone || 'IST (UTC+5:30)',
      notes: b.notes,
      status: 'pending',
      notificationSentTo: [] as string[],
    };

    const bookings = getStoredBookings();
    bookings.unshift(booking);
    saveBookings(bookings);
    console.log(`[Booking] Request received: ${booking.id}`);

    res.status(201).json({
      success: true,
      message: 'Booking request recorded. The instructor will contact you to confirm the class.',
      booking,
    });
  } catch {
    console.error('Booking processing error');
    res.status(500).json({ error: 'Failed to process booking request.' });
  }
});

// GET /api/bookings: publisher only. Contains parents' contact details.
router.get('/bookings', requirePublisherAuth, (_req: Request, res: Response) => {
  const bookings = getStoredBookings();
  res.json({ bookings, count: bookings.length });
});

export default router;
