import crypto from 'crypto';
import { Request, Response, NextFunction, CookieOptions } from 'express';
import jwt from 'jsonwebtoken';

export const JWT_ISSUER = 'portfolio-site';
export const SESSION_HOURS = 12;
let secret = '';

// Called once at startup. Production refuses to start without a strong secret.
// Outside production a random per-process secret is used, so no known default ever exists.
export function assertAuthConfig(isProd: boolean) {
  const env = process.env.JWT_SECRET;
  if (isProd && (!env || env.length < 32)) {
    throw new Error('JWT_SECRET must be set to a random string of at least 32 characters.');
  }
  secret = env && env.length >= 32 ? env : crypto.randomBytes(48).toString('hex');
}

export function getJwtSecret() {
  if (!secret) throw new Error('Auth is not configured.');
  return secret;
}

export function cookieOptions(): CookieOptions {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/',
  };
}

export interface AuthenticatedUser {
  id: string;
  name: string;
  email: string;
  role: 'publisher';
}

export interface AuthRequest extends Request {
  user?: AuthenticatedUser;
}

export function requirePublisherAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.cookies?.token;
  if (!token || typeof token !== 'string') {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  try {
    const decoded = jwt.verify(token, getJwtSecret(), { algorithms: ['HS256'], issuer: JWT_ISSUER }) as AuthenticatedUser;
    if (!decoded || decoded.role !== 'publisher') {
      return res.status(403).json({ error: 'Forbidden.' });
    }
    req.user = { id: decoded.id, name: decoded.name, email: decoded.email, role: decoded.role };
    next();
  } catch {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
}
