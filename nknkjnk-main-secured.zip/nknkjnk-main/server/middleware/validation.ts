import { Request, Response, NextFunction } from 'express';
import { z, ZodError } from 'zod';
import sanitizeHtml from 'sanitize-html';

// Plain-text fields: drop angle brackets and control characters. React escapes text on output.
const clean = (s: string) => s.replace(/[<>]/g, '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim();
const text = (max: number, min = 0) => z.string().max(max).transform(clean).pipe(z.string().min(min));
const optionalText = (max: number) =>
  z.string().max(max).nullish().transform((v) => clean(v ?? ''));

// Rich text: allowlist only. Scripts, event handlers, iframes, styles and javascript: URLs are removed.
export function sanitizePostHtml(html: string): string {
  return sanitizeHtml(html, {
    allowedTags: [
      'p', 'br', 'hr', 'h1', 'h2', 'h3', 'h4', 'strong', 'b', 'em', 'i', 'u', 's', 'blockquote',
      'ul', 'ol', 'li', 'a', 'img', 'code', 'pre', 'span', 'div', 'sub', 'sup',
    ],
    allowedAttributes: { a: ['href', 'title'], img: ['src', 'alt', 'title', 'width', 'height'] },
    allowedSchemes: ['http', 'https', 'mailto'],
    allowedSchemesByTag: { img: ['http', 'https', 'data'] },
    allowProtocolRelative: false,
    transformTags: {
      a: sanitizeHtml.simpleTransform('a', { rel: 'noopener noreferrer nofollow', target: '_blank' }),
    },
  });
}

const safeImage = z
  .string()
  .max(5_000_000)
  .refine(
    (v) => v === '' || /^https:\/\//i.test(v) || /^\/[^/\\]/.test(v) || /^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(v),
    'Cover image must be an https link, a site path, or an uploaded image'
  );

export const loginSchema = z.object({
  email: z.string().max(254).email('Valid email address is required'),
  password: z.string().min(1, 'Password is required').max(200),
});

export const postSchema = z.object({
  title: text(200, 2),
  slug: z.string().min(2).max(200).regex(/^[a-zA-Z0-9\s_-]+$/, 'Slug may only contain letters, numbers, spaces and dashes').optional(),
  content: z.string().max(500_000).transform(sanitizePostHtml).pipe(z.string().min(5, 'Post content must be at least 5 characters')),
  excerpt: text(500).optional().default(''),
  coverImage: safeImage.optional().default(''),
  tags: z.array(text(40, 1)).max(20).optional().default([]),
  category: text(60, 1).default('General'),
  status: z.enum(['draft', 'published']).default('published'),
});

export const bookingSchema = z.object({
  parentName: text(100, 1),
  studentName: text(100, 1),
  studentGrade: optionalText(50),
  subjectInterest: optionalText(100),
  email: z.string().trim().max(254).email().transform((v) => v.toLowerCase()),
  phone: z.string().trim().regex(/^[+0-9()\-\s]{7,20}$/, 'Enter a valid phone number'),
  preferredDate: optionalText(20),
  preferredTime: optionalText(50),
  timezone: optionalText(50),
  notes: optionalText(1000),
});

export function validateBody(schema: z.ZodType) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        return res.status(400).json({ error: err.issues.map((e) => e.message).join(', ') });
      }
      return res.status(400).json({ error: 'Invalid request payload' });
    }
  };
}
