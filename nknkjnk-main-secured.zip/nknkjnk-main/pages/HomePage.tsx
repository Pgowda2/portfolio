import React from 'react';
import { Navbar } from '../components/Navbar.js';
import { HeroSection } from '../components/HeroSection.js';
import { AboutSection } from '../components/AboutSection.js';
import { ExperienceSection } from '../components/ExperienceSection.js';
import { SkillsSection } from '../components/SkillsSection.js';
import { CurriculumSection } from '../components/CurriculumSection.js';
import { InteractiveCodePlayground } from '../components/InteractiveCodePlayground.js';
import { EducationSection } from '../components/EducationSection.js';
import { TeachingPhilosophySection } from '../components/TeachingPhilosophySection.js';
import { ResumeSection } from '../components/ResumeSection.js';
import { ContactSection } from '../components/ContactSection.js';
import { Footer } from '../components/Footer.js';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#fafcff] dark:bg-[#0a0e17] text-gray-900 dark:text-gray-100 flex flex-col font-sans transition-colors duration-200 relative overflow-x-hidden selection:bg-brand-500 selection:text-white">
      {/* Dynamic Refreshing Ambient Background Elements */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
        {/* Fresh micro-dot grid layer */}
        <div className="absolute inset-0 bg-dot-pattern dark:bg-dot-pattern-dark opacity-35 dark:opacity-20" />





      </div>

      {/* Global Navigation */}
      <div className="relative z-50">
        <Navbar />
      </div>

      {/* Main Content Sections */}
      <main className="flex-1 relative z-10">
        <HeroSection />
        <AboutSection />
        <ExperienceSection />
        <SkillsSection />
        <CurriculumSection />
        <InteractiveCodePlayground />
        <EducationSection />
        <TeachingPhilosophySection />
        <ResumeSection />
        <ContactSection />
      </main>

      {/* Global Footer */}
      <div className="relative z-10">
        <Footer />
      </div>
    </div>
  );
};
