import React from 'react';
import { LegalLayout, LegalSection } from '../components/LegalLayout.js';
import { PERSONAL_INFO } from '../data/portfolioData.js';

const sections: LegalSection[] = [
  {
    heading: 'About this site',
    body: [
      `This site presents the teaching profile of ${PERSONAL_INFO.name} and lets parents and guardians request online coding classes for students in Grades 1 to 12. By using it you agree to these terms.`,
    ],
  },
  {
    heading: 'Booking requests',
    body: [
      'Submitting the booking form is a request, not a confirmed class. A class is confirmed only when the instructor replies to you with a date and time. Bookings must be made by a parent or guardian who is at least 18 years old.',
      'Fees, schedules, rescheduling and cancellation terms for paid classes are agreed in writing with the parent or guardian before classes begin. They are not set by this website.',
    ],
  },
  {
    heading: 'Learning outcomes',
    body: [
      'Teaching is tailored to each student, and progress depends on practice and participation. We do not promise specific grades, test results, certificates or career outcomes.',
    ],
  },
  {
    heading: 'Using the site',
    body: [
      'Give accurate information in the booking form. Do not misuse the site, attempt to break into publisher accounts, send spam, or submit content that is unlawful or harmful.',
    ],
  },
  {
    heading: 'Content and ownership',
    body: [
      'The text, images and code on this site belong to the site owner or are used with permission. You may link to the site. You may not copy or republish its content without written permission. Blog posts remain the work of their authors.',
    ],
  },
  {
    heading: 'Links to other sites',
    body: [
      'The site links to third-party pages such as the Codingal profile and LinkedIn. Those sites are not under our control and have their own terms and privacy policies.',
    ],
  },
  {
    heading: 'Availability and liability',
    body: [
      'We try to keep the site accurate and available, but it is provided as is. To the extent allowed by law, the site owner is not liable for losses that result from using the site, from temporary downtime, or from the actions of third-party services such as Google. Nothing here limits any right you have under law that cannot be limited.',
    ],
  },
  {
    heading: 'Governing law',
    body: ['These terms are governed by the laws of India. Disputes will be handled by the courts at Mysuru, Karnataka.'],
  },
  {
    heading: 'Privacy',
    body: ['How we handle personal data is described in the privacy policy, available from the footer of every page.'],
  },
  {
    heading: 'Changes to these terms',
    body: ['We may update these terms. The date at the top shows the latest version. Continued use of the site means you accept the updated terms.'],
  },
];

export const TermsPage: React.FC = () => (
  <LegalLayout
    title="Terms and conditions"
    updated="October 10, 2026"
    intro="These terms apply when you browse this website or send a booking request."
    sections={sections}
  />
);

export default TermsPage;
