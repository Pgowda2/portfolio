import React from 'react';
import { LegalLayout, LegalSection } from '../components/LegalLayout.js';
import { PERSONAL_INFO } from '../data/portfolioData.js';

const sections: LegalSection[] = [
  {
    heading: 'Who is responsible for your data',
    body: [
      `This website is run by ${PERSONAL_INFO.name}, ${PERSONAL_INFO.location}. You can reach the site owner at ${PERSONAL_INFO.email} or ${PERSONAL_INFO.phone}.`,
    ],
  },
  {
    heading: 'What we collect',
    body: [
      'Trial class booking form: parent or guardian name, student name and grade, subject of interest, email address, phone number, preferred date, time and timezone, and any notes you choose to write. Bookings must be made by a parent or guardian, not by a child.',
      'Optional Google sign-in: if you choose to sign in with Google on the booking form, you are asked to allow access to create a calendar event and to send a confirmation email from your own Google account. Sign-in is handled by Firebase Authentication. The calendar and email requests are made from your browser. You can skip sign-in and still send a booking request.',
      'Browser storage: your light or dark theme choice and your high score in the code lab game are kept in your browser on your own device. We do not use advertising or analytics cookies.',
      'Publisher accounts: the site owner and authorised publishers who manage blog posts sign in with an email and password. A secure session cookie is used for that sign-in only.',
    ],
  },
  {
    heading: 'How we use it',
    body: [
      'We use booking details only to reply to you, schedule and run the trial class, and follow up about classes you ask about. We do not sell your data and we do not use it for advertising.',
    ],
  },
  {
    heading: 'Who else handles it',
    body: [
      'Google provides sign-in, calendar and email services if you use them, and serves the fonts used on this site, which means your browser contacts Google servers when a page loads. Our hosting provider stores the booking records and serves the site. Page styling is loaded from the Tailwind CSS content delivery network. These services have their own privacy policies.',
    ],
  },
  {
    heading: 'How long we keep it',
    body: [
      'Booking records are kept for as long as needed to arrange and deliver classes and to answer follow-up questions, then deleted. You can ask us to delete them sooner at any time.',
    ],
  },
  {
    heading: 'Your choices',
    body: [
      'You can ask to see, correct or delete the personal data we hold about you or your child by emailing us. You can clear browser storage in your browser settings, and you can withdraw Google permissions at any time from your Google Account security settings. If you are in India, you have rights over your personal data under the Digital Personal Data Protection Act, 2023, and we will respond to requests made under it.',
    ],
  },
  {
    heading: 'Children',
    body: [
      'This site is not directed at children. We collect a child\'s name and grade only when a parent or guardian provides it to arrange classes.',
    ],
  },
  {
    heading: 'Changes to this page',
    body: ['If we change how we handle data, we will update this page and the date at the top.'],
  },
];

export const PrivacyPage: React.FC = () => (
  <LegalLayout
    title="Privacy policy"
    updated="October 10, 2026"
    intro="This page explains what personal information this website collects when you book a trial class or sign in, why, and what you can do about it."
    sections={sections}
  />
);

export default PrivacyPage;
