import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  withCredentials: true, // Send and receive httpOnly cookies
  headers: {
    'Content-Type': 'application/json',
  },
});

// Response interceptor to handle unhandled errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.error || error.message || 'An unexpected error occurred';
    return Promise.reject(new Error(message));
  }
);

export default api;
