import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { PERSONAL_INFO } from '../data/portfolioData.js';

export interface LegalSection {
  heading: string;
  body: string[];
}

interface LegalLayoutProps {
  title: string;
  updated: string;
  intro: string;
  sections: LegalSection[];
}

export const LegalLayout: React.FC<LegalLayoutProps> = ({ title, updated, intro, sections }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = `${title} | ${PERSONAL_INFO.name}`;
  }, [title]);

  return (
    <div className="min-h-screen bg-white dark:bg-[#0a0e17] text-gray-900 dark:text-gray-100 font-sans">
      <header className="border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <Link to="/" className="font-bold text-sm hover:text-brand-600 dark:hover:text-brand-400">
            {PERSONAL_INFO.name}
          </Link>
          <Link to="/" className="text-sm text-gray-600 dark:text-gray-400 hover:text-brand-600 dark:hover:text-brand-400">
            Back to home
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <h1 className="font-serif text-4xl font-semibold tracking-tight mb-2">{title}</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Last updated: {updated}</p>
        <p className="text-base leading-relaxed text-gray-700 dark:text-gray-300 mb-10">{intro}</p>

        {sections.map((section) => (
          <section key={section.heading} className="mb-8">
            <h2 className="text-xl font-semibold mb-3">{section.heading}</h2>
            {section.body.map((paragraph) => (
              <p key={paragraph} className="text-base leading-relaxed text-gray-700 dark:text-gray-300 mb-3">
                {paragraph}
              </p>
            ))}
          </section>
        ))}

        <p className="text-sm text-gray-500 dark:text-gray-400 pt-6 border-t border-gray-200 dark:border-gray-800">
          Questions about this page: <a className="underline" href={`mailto:${PERSONAL_INFO.email}`}>{PERSONAL_INFO.email}</a>
        </p>
      </main>
    </div>
  );
};
