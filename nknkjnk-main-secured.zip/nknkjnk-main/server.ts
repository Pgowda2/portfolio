import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';

import { connectDB } from './server/db.js';
import { seedDatabase } from './server/seed.js';
import { assertAuthConfig } from './server/middleware/auth.js';
import authRoutes from './server/routes/auth.js';
import postRoutes from './server/routes/posts.js';
import bookingsRoutes from './server/routes/bookings.js';

// Production is the default. Development mode must be requested explicitly with --dev.
const isDev = process.argv.includes('--dev');
if (!isDev) process.env.NODE_ENV = 'production';
const isProd = !isDev;
const PORT = Number(process.env.PORT) || 3000;

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

function limiter(windowMs: number, max: number, error: string, skipSuccessfulRequests = false) {
  return rateLimit({ windowMs, max, skipSuccessfulRequests, standardHeaders: true, legacyHeaders: false, message: { error } });
}

async function startServer() {
  assertAuthConfig(isProd);
  await connectDB();
  await seedDatabase();

  const app = express();
  app.disable('x-powered-by');
  // Needed so rate limits see the real client IP behind a hosting proxy. Set TRUST_PROXY=0 if there is no proxy.
  app.set('trust proxy', Number(process.env.TRUST_PROXY ?? (isProd ? 1 : 0)));

  const cspDirectives = {
    defaultSrc: ["'self'"],
    // 'unsafe-inline' is required while Tailwind runs from its CDN with an inline config in index.html.
    scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com', 'https://apis.google.com'],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    imgSrc: ["'self'", 'data:', 'https:'],
    connectSrc: ["'self'", 'https://*.googleapis.com', 'https://*.firebaseapp.com'],
    frameSrc: ['https://accounts.google.com', 'https://*.firebaseapp.com'],
    objectSrc: ["'none'"],
    baseUri: ["'self'"],
    formAction: ["'self'"],
    frameAncestors: ["'none'"],
  };

  app.use(
    helmet({
      contentSecurityPolicy: isProd
        ? { directives: cspDirectives, reportOnly: process.env.CSP_REPORT_ONLY === 'true', useDefaults: false }
        : false,
      // Google sign-in uses a popup, which needs this value instead of the default 'same-origin'.
      crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
      crossOriginEmbedderPolicy: false,
      referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
      hsts: isProd ? { maxAge: 31536000, includeSubDomains: true } : false,
    })
  );
  app.use((_req, res, next) => {
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    next();
  });

  // The site and API share one origin, so CORS is off unless origins are listed explicitly.
  if (allowedOrigins.length > 0) {
    app.use('/api', cors({ origin: allowedOrigins, credentials: true }));
  }

  // Reject cross-site state-changing requests (CSRF defence on top of SameSite cookies).
  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    const origin = req.headers.origin;
    if (!origin) return next();
    try {
      if (new URL(origin).host === req.headers.host || allowedOrigins.includes(origin)) return next();
    } catch {
      /* fall through */
    }
    return res.status(403).json({ error: 'Cross-site request blocked.' });
  });

  app.use(cookieParser());
  // Posts may carry a base64 cover image, so they get a larger limit. Everything else stays small.
  app.use('/api/posts', express.json({ limit: '6mb' }));
  app.use('/api/publisher', express.json({ limit: '6mb' }));
  app.use(express.json({ limit: '50kb' }));

  app.use('/api', limiter(15 * 60 * 1000, 300, 'Too many requests. Please slow down.'));
  app.use('/api/auth/login', limiter(15 * 60 * 1000, 10, 'Too many login attempts. Try again in 15 minutes.', true));
  app.post('/api/bookings', limiter(60 * 60 * 1000, 5, 'Too many booking requests. Please try again later.'));

  app.use('/api/auth', authRoutes);
  app.use('/api', postRoutes);
  app.use('/api', bookingsRoutes);

  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { dotfiles: 'ignore', index: false }));
    app.get('*all', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  // Never leak stack traces or internals to clients.
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large.' });
    if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON.' });
    console.error('Unhandled error:', err?.message || err);
    res.status(500).json({ error: 'Something went wrong.' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT} (${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err?.message || err);
  process.exit(1);
});
